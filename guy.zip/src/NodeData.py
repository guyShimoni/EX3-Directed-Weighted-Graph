class NodeData:

    def __init__(self, key: int=-1, pos: tuple = None ,tag: float = -1 , info: str = "white"):
        self.__key = key
        self.__pos = pos
        self.__tag = tag
        self.__info = info

    def get_key(self):
        return self.__key

    def get_info(self):
        return self.info

    def set_info(self, inf):
        self.__info = inf

    def get_tag(self):
        return self.tag

    def set_tag(self, tg):
        self.__tag = tg

    def get_pos(self):
        return self.pos

    def set_tag(self, t):
        self.__pos = t

