

from GraphInterface import GraphInteface

"""
Simple graph implementation
"""

class DiGraph(GraphInteface):


    def __init__(self):
        """Represent a graph as a dictionary of vertices mapping labels to edges."""
        self.vertices = {}
        self.vertex = []
        self.edges = [[]]
        self.mc = 0
        self.edge_size = 0



    def v_size(self) -> int:
        # return the size vertex
        return len(self.vertex)

    def e_size(self) -> int:
        return self.edge_size

    def get_all_v(self) -> dict:
        return self.vertex

    def all_in_edges_of_node(self, id1: int) -> dict:
        try:
            return self.vertex[id1].get_in_neighbors()
        except KeyError:
            return dict()



    def all_out_edges_of_node(self, id1: int) -> dict:
        return 0

    def get_mc(self) -> int:
        return 0

    def add_edge(self, id1: int, id2: int, weight: float) -> bool:
        return 0

    def add_node(self, node_id: int, pos: tuple = None) -> bool:
        return 0

    def remove_node(self, node_id: int) -> bool:
        return 0

    def remove_edge(self, node_id1: int, node_id2: int) -> bool:
        return 0